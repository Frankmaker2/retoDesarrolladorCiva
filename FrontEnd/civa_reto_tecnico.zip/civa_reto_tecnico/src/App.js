import { useState } from 'react';
import './App.css';
import ListComponent from './components/ListComponent'
import PlayerComponent from './components/PlayerComponent';
import Banner from './components/Banner';
import Footer from './components/Footer';

function App() {
  const [mostrarLista, setMostrarLista] = useState(false);
  const [mostrarFutbolista, setMostrarFutbolista] = useState(false);

  const toggleLista1 = () => {
    setMostrarLista(!mostrarLista)
    setMostrarFutbolista(false);
  }

  const toggleLista2 = () => {
    setMostrarFutbolista(!mostrarFutbolista);
    setMostrarLista(false)
  }

  
  return (
    <div className="">
      <h1 className='text-center title'>Dallas Page</h1>
      <div>
        <Banner></Banner>
      </div>
      <div className='container-fluid'>
      <div className='row text-center'>
        <div className='col-7'>
          <p className='fs-2 py-3 mb-0'>This is our list of players</p>
          <button type="button" className="btn btn-outline-primary m-4" onClick={toggleLista1}>Show List</button>
            {
              mostrarLista && (
                <ListComponent></ListComponent>
              )
            }
        </div>

        <div className='col-4'>
          <p className='fs-2 py-3 mb-0'>Review the data of our players</p>
          <button type="button" class="btn btn-outline-primary m-4" onClick={toggleLista2}>Search Player</button>
            {
              mostrarFutbolista && (
                <PlayerComponent></PlayerComponent>
              )
            }
        </div>

        <Footer></Footer>

            
      </div>
      </div>
      
    </div>
  );
}

export default App;
