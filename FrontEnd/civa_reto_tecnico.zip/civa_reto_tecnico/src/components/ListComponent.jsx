import React, {useState, useEffect} from 'react'

const SearchComponents = () => {
    const [users, setUsers] = useState([])

    const URL = "http://localhost:8081/api/futbolista"

    const showData = async () =>{
        const response = await fetch(URL)
        const data = await response.json()
        setUsers(data)
    }
    

    useEffect(() => {
        showData()
    },[])

  return (
    <div className='ms-2 mt-2'>
        <table class="table">
            <thead className='text-center'>
                <tr className='bg-curso text-white'>
                    <th>#</th>
                    <th>Football player's name</th>
                    <th>Player's last name</th>
                    <th>Date of birth</th>
                    <th>Characteristics</th>
                    <th>Position</th>
                </tr>
            </thead>
            <tbody className='text-center'>
                {
                    users.map((data) =>(
                        <tr key={data.id}>
                            <td>{data.idFutbolista}</td>
                            <td>{data.nombresFutbolista}</td>
                            <td>{data.apellidosFutbolista}</td>
                            <td>{data.fechaNacimientoFutbolista}</td>
                            <td>{data.caracteristicasFutbolista}</td>
                            <td>{data.posicion.nombrePosicion}</td>
                        </tr>
                    ))
                }
            </tbody>
        </table>      
    </div>
  )
}

export default SearchComponents

