import React from 'react'

const Footer = () => {
  return (
    <>
        <div className='final m-0 py-5'>
            <p className='m-0 foot'>Diseñado y Realizado con React y Java por Frank Melgarejo </p>
        </div>
    </>
  )
}

export default Footer
