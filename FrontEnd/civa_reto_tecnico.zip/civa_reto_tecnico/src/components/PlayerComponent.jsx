import React from 'react'
import axios from 'axios';
import { useState } from 'react'

const PlayerComponent = () => {
    var [id, setId] = useState('');
    var [datosPersona, setDatosPersona] = useState(null);

    const buscar = async () => {
        try{
          const response = await axios.get(`http://localhost:8081/api/futbolista/${id}`);
          const datosEncontrados = response.data;
          setDatosPersona(datosEncontrados);
        } catch(error){
          console.error('Error al buscar los datos:', error);
        }
      };

  return (
    <div>
      <div className='col'>
          <input type='text' value={id} onChange={(e) => setId(e.target.value)} placeholder='Id' className='form-control'></input>
          <button type="button" className="btn btn-primary m-4" onClick={buscar}>Buscar</button>
          <div className='row'>
            <div className='col mb-3'> 
              {datosPersona && (
                <div className="card ">
                  <img src="" className="card-img-top imagen" alt=""></img>
                <div className="card-body">
                  <h5 className="card-title">Datos del Futbolista</h5>
                  <p className="card-text">Nombre: {datosPersona.nombresFutbolista}</p>
                  <p className="card-text">Apellido: {datosPersona.apellidosFutbolista}</p>
                  <p className="card-text">Fecha de Nacimiento: {datosPersona.fechaNacimientoFutbolista}</p>
                  <p className="card-text">Caracteristicas del Futbolista: {datosPersona.caracteristicasFutbolista}</p>
                  <p className="card-text">Posición: {datosPersona.posicion.nombrePosicion}</p>
                </div>
              </div>
                
              )}
            </div>
          </div>
        </div>
    </div>
  )
}

export default PlayerComponent
